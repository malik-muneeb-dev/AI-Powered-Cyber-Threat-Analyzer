let typingTimer;

document.addEventListener('input', (e) => {
    // Sirf password type ki input field par kaam karega
    if (e.target.type === 'password') {
        let value = e.target.value.trim();
        
        clearTimeout(typingTimer);
        typingTimer = setTimeout(() => {
            // Kam az kam 6 characters hon tabhi check karein
            if (value.length >= 6) {
                if (chrome.runtime && chrome.runtime.id) {
                    chrome.runtime.sendMessage({ 
                        type: "CHECK_PWD", 
                        password: value 
                    });
                }
            }
        }, 800); // 800ms ka gap (User ko type karne ka sukoon dein)
    }
});

