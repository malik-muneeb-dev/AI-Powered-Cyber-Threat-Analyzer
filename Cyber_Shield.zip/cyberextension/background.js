let notificationUrls = {};

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === "CHECK_PWD") {
        fetch('http://127.0.0.1:5000/analyze', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ password: request.password })
        })
        .then(res => res.ok ? res.json() : null)
        .then(data => {
            // 1. Check karein ke backend ne Extension ko OFF toh nahi kiya
            if (!data || data.status === "inactive") {
                console.log("Extension is disabled from dashboard.");
                return;
            }

            // 2. Agar Strength mojud hai tabhi notification dikhao
            if (!data.strength) return;

            let notifId = "pwd_" + Date.now();
            notificationUrls[notifId] = `http://127.0.0.1:5000/password-tool?val=${encodeURIComponent(request.password)}`;
            
            let strengthStr = String(data.strength).toLowerCase();
            let isStrong = (strengthStr === "strong" || strengthStr === "safe");

            chrome.notifications.create(notifId, {
                type: "basic", 
                iconUrl: "icon.png",
                title: isStrong ? "✅ SECURE PASSWORD" : "⚠️ WEAK PASSWORD DETECTED",
                message: `AI Analysis: ${data.strength}. Click to see detailed security audit.`,
                priority: 2
            });
        })
        .catch(err => console.log("Extension Error: Server down or Connection issue"));
    }
    return true; 
});

chrome.notifications.onClicked.addListener((id) => {
    if (notificationUrls[id]) {
        chrome.tabs.create({ url: notificationUrls[id] });
        delete notificationUrls[id];
    }
});
